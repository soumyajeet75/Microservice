package com.billing.controller;

import com.billing.entity.User;
import com.billing.services.BillingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
@RequestMapping("/billing")
public class BillingController {
    @Autowired
    private BillingService billingService;

    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/payment/{userid}")
    public boolean payment(@PathVariable("userid") Long userId)
    {
        List<Long> availService=this.restTemplate.getForObject("http://user-service/user/getavailservices/"+userId, List.class);
        List<Long> bookedService=this.restTemplate.getForObject("http://user-service/user/getbookedservices/"+userId, List.class);
        for(Long i:bookedService)
        {
            availService.add(i);
        }
        this.restTemplate.postForEntity("http://user-service/user/setavailservices/"+userId,availService,List.class);
        return true;
    }
}
