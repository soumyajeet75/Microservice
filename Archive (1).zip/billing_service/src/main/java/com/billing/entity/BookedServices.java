package com.billing.entity;

public class BookedServices {
    private Long serviceId;
    private String name;
    private Long userId;

    public BookedServices() {
    }

    public BookedServices(Long serviceId, String name, Long userId) {
        this.serviceId = serviceId;
        this.name = name;
        this.userId = userId;
    }

    public Long getServiceId() {
        return serviceId;
    }

    public String getName() {
        return name;
    }

    public Long getUserId() {
        return userId;
    }
}
