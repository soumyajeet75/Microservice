package com.billing.entity;

import java.util.ArrayList;
import java.util.List;

public class User {
    private Long userId;
    List<BookedServices> bookedServices=new ArrayList<>();

    public User() {
    }

    public User(Long userId) {
        this.userId = userId;
    }

    public Long getUserId() {
        return userId;
    }

    public List<BookedServices> getBookedServices() {
        return bookedServices;
    }
}
