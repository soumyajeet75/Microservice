package com.billing.services;


import com.billing.entity.User;

import java.util.List;

public interface BillingService {
    public User getUser(Long id);
}
