package com.billing.services;
import com.billing.entity.BookedServices;
import com.billing.entity.User;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BillingServiceImp implements BillingService{

    List<User> list= List.of(
            new User(1L),
            new User(2L)
    );

    @Override
    public User getUser(Long id) {
        return this.list.stream().filter(user->user.getUserId().equals(id)).findAny().orElse(null);
    }
}
