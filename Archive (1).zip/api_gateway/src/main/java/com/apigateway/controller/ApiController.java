package com.apigateway.controller;
import com.apigateway.entity.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class ApiController {
    @RequestMapping(value = "/signup", method = RequestMethod.GET)
    public String signUpPage(Model model)
    {
        model.addAttribute("user", new User());
        return "signup";
    }

    @PostMapping("/register")
    public String showPage(@ModelAttribute("user") User u) {

        System.out.println("Date planted: " + u.getEmailId() +"          "+ u); //in reality, you'd use a logger instead :)
        return "homepage";
    }

    @GetMapping("/login")
    public String logInPage()
    {
        return "login";
    }
    @GetMapping("/homepage")
    public String homePage()
    {
        return "homepage";
    }
    @GetMapping("/service")
    public String servicePage()
    {
        return "service";
    }
    @GetMapping("/billing")
    public String billingPage()
    {
        return "billing";
    }
}
