package com.apigateway.controller;

import com.apigateway.entity.User;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

public class ApiGateWayRestController {
}
