package com.apigateway.entity;

public class HospitalServices {
    private Long serviceId;
    private String name;
    private String price;

    public HospitalServices() {
    }

    public HospitalServices(Long serviceId, String name, String price) {
        this.serviceId = serviceId;
        this.name = name;
        this.price = price;
    }

    public Long getServiceId() {
        return serviceId;
    }

    public String getName() {
        return name;
    }

    public String getPrice() {
        return price;
    }
}
