package com.apigateway.entity;

import java.util.ArrayList;
import java.util.List;

public class User {
    private Long userId;
    private String userDOB;
    private String password;
    private String emailId;
    List<HospitalServices> availServices=new ArrayList<>();
    List<HospitalServices> bookedServices=new ArrayList<>();

    public User() {
    }

    public User(Long userId, String userDOB, String password, String emailId) {
        this.userId = userId;
        this.userDOB = userDOB;
        this.password = password;
        this.emailId = emailId;
    }

    public User( String emailId, String userDOB, String password) {
        this.userDOB = userDOB;
        this.password = password;
        this.emailId = emailId;
    }

    public User(Long userId, String userDOB, String password, String emailId, List<HospitalServices> availServices, List<HospitalServices> bookedServices) {
        this.userId = userId;
        this.userDOB = userDOB;
        this.password = password;
        this.emailId = emailId;
        this.availServices = availServices;
        this.bookedServices = bookedServices;
    }

    public Long getUserId() {
        return userId;
    }

    public String getUserDOB() {
        return userDOB;
    }

    public String getPassword() {
        return password;
    }

    public String getEmailId() {
        return emailId;
    }

    public List<HospitalServices> getAvailServices() {
        return availServices;
    }

    public List<HospitalServices> getBookedServices() {
        return bookedServices;
    }
}
