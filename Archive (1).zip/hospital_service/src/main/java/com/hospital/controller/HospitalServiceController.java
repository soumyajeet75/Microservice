package com.hospital.controller;

import com.hospital.entity.HospitalServices;
import com.hospital.services.HospitalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/service")
public class HospitalServiceController {
    @Autowired
    private HospitalService hospitalService;
    @GetMapping("/{serviceId}")
    public HospitalServices getHospitalServicesByServiceId(@PathVariable("serviceId") Long serviceId)
    {
        return hospitalService.getHospitalServicesByServiceId(serviceId);
    }
    @GetMapping("/addservice")
    public boolean addHospitalServices(HospitalServices service)
    {
        hospitalService.addService(service);
        return true;
    }
}