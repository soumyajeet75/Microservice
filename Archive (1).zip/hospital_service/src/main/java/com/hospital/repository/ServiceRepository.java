package com.hospital.repository;

import com.hospital.entity.HospitalServices;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ServiceRepository extends MongoRepository<HospitalServices, String> {
    HospitalServices findByEmailId(String emailId);
    HospitalServices findById(Long userId);
}
