package com.hospital.services;

import com.hospital.entity.HospitalServices;
import com.hospital.repository.ServiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HospitalServiceImp implements HospitalService {

    @Autowired
    ServiceRepository serviceRepository;

    @Override
    public HospitalServices getHospitalServicesByServiceId(Long serviceId) {
        return serviceRepository.findById(serviceId);
    }

    @Override
    public void addService(HospitalServices service) {
        serviceRepository.save(service);
    }
}
