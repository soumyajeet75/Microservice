package com.hospital.services;

import com.hospital.entity.HospitalServices;

import java.util.List;

public interface HospitalService {
    HospitalServices getHospitalServicesByServiceId(Long serviceId);

    void addService(HospitalServices service);
}
