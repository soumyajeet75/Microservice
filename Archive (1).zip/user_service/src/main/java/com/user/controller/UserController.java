package com.user.controller;

import com.user.entity.User;
import com.user.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/{userId}")
    public boolean login(User u)
    {
        User user = userService.getUserByEmailId(u.getEmailId());
        if(u.getPassword().equals(user.getPassword()))
            return true;
        return false;
    }

    @PostMapping("/signup")
    public boolean signup(User user)
    {
        userService.addUser(user);
        return true;
    }

    @PostMapping("/addservice/{userId}/{serviceId}")
    public boolean addInAvailService(@PathVariable("userId") Long userId,@PathVariable("serviceId") Long serviceId)
    {
        User user = userService.getUserByUserId(userId);
        List<Long> availService = user.getAvailServices();
        availService.add(serviceId);
        user.setAvailServices(availService);
        return true;
    }

    @PostMapping("/getavailservices/{userId}")
    public List<Long> getAvailService(@PathVariable("userId") Long userId)
    {
        User user = userService.getUserByUserId(userId);
        return user.getAvailServices();
    }
    @PostMapping("/getbookedservices/{userId}")
    public List<Long> getBookedService(@PathVariable("userId") Long userId)
    {
        User user = userService.getUserByUserId(userId);
        return user.getBookedServices();
    }
    @PostMapping("/setavailservices/{userId}")
    public boolean setAvailService(@PathVariable("userId") Long userId,List<Long> availServices)
    {
        User user = userService.getUserByUserId(userId);
        user.setBookedServices(new ArrayList<Long>());
        user.setAvailServices(availServices);
        userService.addUser(user);
        return true;
    }
}
