package com.user.services;

import com.user.entity.User;

public interface UserService {
    public User getUserByUserId(Long userId);
    public User getUserByEmailId(String emailId);
    public void addUser(User user);
}
