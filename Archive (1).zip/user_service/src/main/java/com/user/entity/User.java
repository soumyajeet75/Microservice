package com.user.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

@Document
public class User {
    @Id
    private Long userId;
    private String userDOB;
    private String password;
    private String emailId;
    private int role;
    List<Long> availServices=new ArrayList<>();
    List<Long> bookedServices=new ArrayList<>();

    public User() {
    }

    public User(Long userId, String userDOB, String password, String emailId) {
        this.userId = userId;
        this.userDOB = userDOB;
        this.password = password;
        this.emailId = emailId;
    }

    public User(Long userId, String userDOB, String password, String emailId, int role, List<Long> availServices, List<Long> bookedServices) {
        this.userId = userId;
        this.userDOB = userDOB;
        this.password = password;
        this.emailId = emailId;
        this.role = role;
        this.availServices = availServices;
        this.bookedServices = bookedServices;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserDOB() {
        return userDOB;
    }

    public void setUserDOB(String userDOB) {
        this.userDOB = userDOB;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public List<Long> getAvailServices() {
        return availServices;
    }

    public void setAvailServices(List<Long> availServices) {
        this.availServices = availServices;
    }

    public List<Long> getBookedServices() {
        return bookedServices;
    }

    public void setBookedServices(List<Long> bookedServices) {
        this.bookedServices = bookedServices;
    }

    public int getRole() {
        return role;
    }

    public void setRole() {
        this.role = 0;
    }
}
